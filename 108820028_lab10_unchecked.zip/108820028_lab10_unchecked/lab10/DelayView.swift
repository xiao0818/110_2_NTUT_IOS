//
//  DelayView.swift
//  lab10
//
//  Created by Eddie on 2022/6/4.
//

import SwiftUI

struct DelayView: View {
    var body: some View {
        LazyView(ContentView())
    }
}

struct DelayView_Previews: PreviewProvider {
    static var previews: some View {
        DelayView()
    }
}
