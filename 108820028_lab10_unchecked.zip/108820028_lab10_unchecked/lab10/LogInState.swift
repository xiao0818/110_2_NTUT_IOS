//
//  LogInState.swift
//  lab10
//
//  Created by Eddie on 2022/6/4.
//

import Foundation
import FirebaseAuth

class LogInState: ObservableObject {
    @Published var isGoLogInView = (Auth.auth().currentUser != nil)
    @Published var isGoSignInView = ((Auth.auth().currentUser != nil) == false)
}
