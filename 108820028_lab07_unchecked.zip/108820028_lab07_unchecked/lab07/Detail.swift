//
//  BandDetail.swift
//  lab07
//
//  Created by Eddie on 2022/5/11.
//

import SwiftUI

struct Detail: View {
    let band: Band
    var body: some View {
        TabView {
            BandDetail(band: band)
                .tabItem {
                    Label("Introduction", systemImage: "music.house.fill")
                }
            RecordList(records: band.records)
                .tabItem {
                    Label("Record", systemImage: "record.circle.fill")
                }
            LinkPage(band: band)
                .tabItem {
                    Label("Link", systemImage: "link.circle.fill")
                }
        }
        .navigationTitle(band.name)
    }
}

struct Detail_Previews: PreviewProvider {
    static var previews: some View {
        Detail(band: .demoBand)
    }
}
