import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    var result:String! = ""
//    var previousAction:Float! = 0
    var action:Int! = 1
    var answer:Float! = 0
    var formula:String! = ""
    
    @IBOutlet var resultLabel: UILabel!
    @IBOutlet var formulaLabel: UILabel!
    
    @IBAction func CLickNumberButton(_ sender: UIButton) {
        let input:String! = String(sender.currentTitle!)
        if(result == "0"){
            result = String(input)
        }else{
            result += String(input)
        }
        resultLabel.text = String(result)
    }
    
    @IBAction func ClearAll(_ sender: UIButton) {
        result = ""
        resultLabel.text = ""
        formula = ""
        formulaLabel.text = ""
        answer = 0
        action = 1
    }
    
    func calc(){
        formulaLabel.text = String(formula)
        if(action == 1){
            answer = answer + Float(result!)!
        }else if(action == 2){
            answer = answer - Float(result!)!
        }else if(action == 3){
            answer = answer * Float(result!)!
        }else if(action == 4){
            answer = answer / Float(result!)!
        }
        resultLabel.text = String(answer)
    }
    
    @IBAction func Equal(_ sender: UIButton) {
        formula += result
        formula += "="
        calc()
        action = 1
    }
    
    @IBAction func Add(_ sender: UIButton) {
        formula += result
        formula += "+"
        calc()
        action = 1
        result = String(0)
    }
    
    @IBAction func Subtract(_ sender: UIButton) {
        formula += result
        formula += "-"
        calc()
        action = 2
        result = String(0)
    }
    
    @IBAction func Multiply(_ sender: UIButton) {
        formula += result
        formula += "*"
        calc()
        action = 3
        result = String(0)
    }
    
    @IBAction func Divide(_ sender: UIButton) {
        formula += result
        formula += "/"
        calc()
        action = 4
        result = String(0)
    }
}

