//
//  ViewController.swift
//  CardMatchingGame
//
//  Created by Eddie on 2022/3/9.
//

import UIKit

class ViewController: UIViewController {
    lazy var game: MatchingGame = MatchingGame(numberOfPairsOfCards: numberOfPairsOfCards)
    
    var numberOfPairsOfCards: Int{
        get{
            return (cardButtons.count / 2)
        }
    }

    @IBOutlet var flipLabel: UILabel!
    @IBOutlet var scoreLabel: UILabel!
    @IBOutlet var themeLabel: UILabel!
    
    @IBOutlet var cardButtons: [UIButton]!
    
    var heartsEmojis = ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍"]
    var arrowsEmojis = ["➡️", "⬅️", "⬆️", "⬇️", "↗️", "↘️", "↙️", "↖️"]
    var moonsEmojis = ["🌕", "🌖", "🌗", "🌘", "🌑", "🌒", "🌓", "🌔"]
    var catsEmojis = ["😺", "😸", "😹", "😻", "😼", "😽", "🙀", "😿"]
    
    var emojisInit: Array<String> = []
    var emojis: Dictionary<Int, String> = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        RandomTheme()
    }

    @IBAction func flipCard(_ sender: UIButton) {
        if let cardNumber = cardButtons.firstIndex(of: sender){
            print("cardNumber = \(cardNumber)")
            game.chooseCard(at: cardNumber)
            updateViewFromModel()
            
        }else{
            print("not in the collection")
        }
    }
    
    func updateViewFromModel(){
        for index in cardButtons.indices{
            let button = cardButtons[index]
            let card = game.cards[index]
            if card.isFaceUp{
                button.setTitle(emoji(for: card), for: UIControl.State.normal)
                button.backgroundColor = card.isMatched ? #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.2) : #colorLiteral(red: 0.9254091382, green: 0.9255421162, blue: 0.9253799319, alpha: 1)
            }else{
                button.setTitle("", for: UIControl.State.normal)
                button.backgroundColor = #colorLiteral(red: 1, green: 0.8, blue: 0, alpha: 1)
            }
        }
        
        if game.AllFaceUp() == true{
            for index in cardButtons.indices{
                cardButtons[index].isEnabled = false
            }
        }else{
            for index in cardButtons.indices{
                cardButtons[index].isEnabled = true
            }
        }
        flipLabel.text = "Flip: \(game.flipCount)"
        scoreLabel.text = "Score: \(game.scoreCount)"
    }
    
    func emoji(for card: Card)->String{
        if emojis[card.identifier] == nil{
            let randomIndex = Int(arc4random_uniform(UInt32(emojisInit.count)))
            emojis[card.identifier] = emojisInit.remove(at: randomIndex)
        }
        return emojis[card.identifier] ?? "?"
    }
    
    @IBAction func FlipAll(_ sender: UIButton) {
        game.FlipAll()
        updateViewFromModel()
    }
    @IBAction func Reset(_ sender: UIButton) {
        game.Reset()
        updateViewFromModel()
        RandomTheme()
    }
    
    func RandomTheme(){
        let randomIndex = Int(arc4random_uniform(UInt32(4)))
        emojis.removeAll()
        if randomIndex == 0{
            themeLabel.text = "Theme: Heart"
            emojisInit.removeAll()
            emojisInit.append(contentsOf: heartsEmojis)
        }else if randomIndex == 1{
            themeLabel.text = "Theme: Arrow"
            emojisInit.removeAll()
            emojisInit.append(contentsOf: arrowsEmojis)
        }else if randomIndex == 2{
            themeLabel.text = "Theme: Moon"
            emojisInit.removeAll()
            emojisInit.append(contentsOf: moonsEmojis)
        }else{
            themeLabel.text = "Theme: Cat"
            emojisInit.removeAll()
            emojisInit.append(contentsOf: catsEmojis)
        }
    }
}
