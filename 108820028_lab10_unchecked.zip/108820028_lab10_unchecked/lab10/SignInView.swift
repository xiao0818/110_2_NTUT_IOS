//
//  SignInView.swift
//  lab10
//
//  Created by Eddie on 2022/6/1.
//

import SwiftUI
import FirebaseAuth

struct SignInView: View {
    @State private var email = ""
    @State private var password = ""
    @EnvironmentObject var state: LogInState
    
    var body: some View {
        VStack {
            TextField("email", text: $email)
                .frame(width: 200)
                .padding()
                .background(.bar)
                .border(.gray , width: 1)
            TextField("password", text: $password)
                .frame(width: 200)
                .padding()
                .background(.bar)
                .border(.gray , width: 1)
            NavigationLink {
                LazyView(DelayView())
            } label: {
                Text("LOGIN")
                    .frame(width: 200)
                    .padding()
                    .foregroundColor(.white)
                    .background(.blue)
                    .border(.gray , width: 1)
            }
            .simultaneousGesture(TapGesture().onEnded({
                Auth.auth().signIn(withEmail: email, password: password)
                sleep(1)
                state.isGoLogInView = (Auth.auth().currentUser != nil)
                state.isGoSignInView = ((Auth.auth().currentUser != nil) == false)
            }))
            HStack {
                Text("Not registered? ")
                    .foregroundColor(.gray)
                NavigationLink {
                    LazyView(CreateView())
                } label: {
                    Text("Create an account")
                        .foregroundColor(.blue)
                }
            }
        }
        .padding()
        .border(.blue , width: 3)
        .navigationBarTitle("")
        .navigationBarHidden(true)
    }
}

struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
    }
}
