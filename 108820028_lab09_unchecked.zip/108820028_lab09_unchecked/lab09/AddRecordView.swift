//
//  AddRecordsView.swift
//  lab09
//
//  Created by Eddie on 2022/5/25.
//

import SwiftUI

struct AddRecordView: View {
    @EnvironmentObject var records: Records
    @Environment(\.dismiss) var dismiss
    @State private var name = ""
    @State private var band = ""
    @State private var description = ""
    
    var body: some View {
        VStack (alignment: .leading){
            Text("Record Name: ")
            TextField("Record Name", text: $name, prompt: Text("Record Name"))
                .padding()
                .cornerRadius(40)
                .overlay(RoundedRectangle(cornerRadius: 40).stroke(Color.blue, lineWidth: 3))
            
            Text("Band Name: ")
            TextField("Band Name", text: $band, prompt: Text("Band Name"))
                .padding()
                .cornerRadius(40)
                .overlay(RoundedRectangle(cornerRadius: 40).stroke(Color.blue, lineWidth: 3))
            
            Text("Record Description: ")
            TextField("Record Description", text: $description, prompt: Text("Record Description"))
                .padding()
                .cornerRadius(40)
                .overlay(RoundedRectangle(cornerRadius: 40).stroke(Color.blue, lineWidth: 3))
            
            Button {
                records.records.append(Record(name: name, band: band, description: description))
                dismiss()
            } label: {
                Text("Submit")
                    .padding()
                    .background(.blue)
                    .foregroundColor(.white)
                    .cornerRadius(40)
            }
        }
        .navigationTitle("Add Record")
    }
}

struct AddRecordView_Previews: PreviewProvider {
    static var previews: some View {
        AddRecordView()
            .environmentObject(Records())
    }
}
