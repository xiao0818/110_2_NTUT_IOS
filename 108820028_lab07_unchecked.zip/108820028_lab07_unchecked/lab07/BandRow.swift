//
//  BandRow.swift
//  lab07
//
//  Created by Eddie on 2022/5/11.
//

import SwiftUI

struct BandRow: View {
    let band: Band
    
    var body: some View {
        HStack {
            Image(band.name)
                .resizable()
                .scaledToFill()
                .frame(width: 80, height: 80)
                .clipped()
            Text(band.name)
            Spacer()
        }
    }
}

struct BandRow_Previews: PreviewProvider {
    static var previews: some View {
        BandRow(band: .demoBand)
    }
}
