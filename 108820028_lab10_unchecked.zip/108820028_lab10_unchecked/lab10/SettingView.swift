//
//  SettingView.swift
//  lab10
//
//  Created by Eddie on 2022/6/1.
//

import SwiftUI
import FirebaseAuth

struct SettingView: View {
    @State private var username = (Auth.auth().currentUser != nil) ? ((Auth.auth().currentUser?.displayName != nil) ? (Auth.auth().currentUser?.displayName)! : "") : ""
    @EnvironmentObject var state: LogInState
    
    var body: some View {
        VStack {
            TextField("username", text: $username)
                .frame(width: 200)
                .padding()
                .background(.bar)
                .border(.gray , width: 1)
            NavigationLink {
                LazyView(DelayView())
            } label: {
                Text("Submit")
                    .frame(width: 200)
                    .padding()
                    .foregroundColor(.white)
                    .background(.blue)
                    .border(.gray , width: 1)
            }
            .simultaneousGesture(TapGesture().onEnded({
                let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                changeRequest?.displayName = username
                changeRequest?.commitChanges()
                sleep(1)
                state.isGoLogInView = (Auth.auth().currentUser != nil)
                state.isGoSignInView = ((Auth.auth().currentUser != nil) == false)
            }))
            HStack {
                Text("Do not want to change username? ")
                    .foregroundColor(.gray)
                NavigationLink {
                    LazyView(LogInView())
                } label: {
                    Text("Back")
                        .foregroundColor(.blue)
                }
            }
        }
        .padding()
        .border(.blue , width: 3)
        .navigationBarTitle("")
        .navigationBarHidden(true)
    }
}

struct SettingView_Previews: PreviewProvider {
    static var previews: some View {
        SettingView()
    }
}
