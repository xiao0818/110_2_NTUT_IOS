//
//  BandList.swift
//  lab07
//
//  Created by Eddie on 2022/5/11.
//

import SwiftUI

struct BandList: View {
    let bands = [
        Band(name: "Vast & Hazy", description: "@vastandhazyofficial\nVH (Vast & Hazy)\n音樂家／樂團\n雙人創作組合 #VH #VastandHazy\n咖咖 @ka_ka_yen 易祺 @gorocktogether\n💿 文明 The Great Beyond 💿：\nbit.ly/3LhdAuj", youtubeUrl: "https://www.youtube.com/user/vasthazy/videos", instagramUrl: "https://www.instagram.com/vastandhazyofficial/?hl=zh-tw", facebookUrl: "https://www.facebook.com/VastandHazy", streetVoiceUrl: "https://streetvoice.com/VastHazy/", records: [
            Record(name: "yet,", description: "yet,\n1 首歌\n1. yet,"),
            Record(name: "Vast&Hazy", description: "Vast&Hazy\n3 首歌\n1. 關於青春\n2. Lost\n3. Vast&Hazy"),
            Record(name: "次等秘密", description: "次等秘密\n3 首歌\n1. 與浪之間\n2. 歸屬\n3. 食人夢"),
            Record(name: "求救訊號", description: "求救訊號\n10 首歌\n1. 求救訊號\n2. 我想成為你\n3. 故障\n4. 關於青春\n5. 指向你的線索\n6. 尋光小路\n7. 拾起\n8. 下次見\n9. yet,\n10. 獨一"),
            Record(name: "文明", description: "文明\n10 首歌\n1. 人類\n2. 文明\n3. 無差別傷害\n4. 複寫\n5. 我完美的愛情\n6. 柔軟的監牢\n7. 被壞妄想\n8. 雨季森林\n9. 夜行樂園\n10. 全員病態就沒人算怪胎")
        ]),
        Band(name: "南西肯恩", description: "@ncknband\n南西肯恩\n音樂家／樂團\n@neciwei @kawhi_ken\nlinkby.tw/ncknband", youtubeUrl: "https://www.youtube.com/channel/UCZrJkYfB83EjJ_A0QZ0ayFw/featured", instagramUrl: "https://www.instagram.com/ncknband/?hl=zh-tw", facebookUrl: "https://www.facebook.com/ncknband", streetVoiceUrl: "https://streetvoice.com/nckn/", records: [
            Record(name: "那麼我想再擁有自己", description: "那麼我想再擁有自己\n3 首歌\n1. 煙花\n2. 練習一個人生活\n3. 無可救藥的貓"),
            Record(name: "Unplugged", description: "Unplugged\n4 首歌\n1. 大海\n2. 惡夢\n3. 把一生都交給了孤獨\n4. 塵緣"),
            Record(name: "可以用這個跟你換那個嗎", description: "可以用這個跟你換那個嗎\n6 首歌\n1. 煙花\n2. 練習一個人生活\n3. 大海\n4. 惡夢\n5. 把一生都交給了孤獨\n6. 塵緣"),
            Record(name: "一個不屬於自己的地方", description: "一個不屬於自己的地方\n11 首歌\n1. 在\n2. 一個不屬於自己的地方\n3. 雲\n4. 煙花\n5. 哪裡\n6. 需要你\n7. 大海\n8. 練習一個人生活\n9. 惡夢\n10. 這個星球有你的名字\n11. 我想再擁有自己"),
            Record(name: "Unplugged 2.0", description: "Unplugged 2.0\n5 首歌\n1. 煙花\n2. 雲\n3. 一個不屬於自己的地方\n4. Purely\n5. 練習一個人生活")
        ])
    ]
    
    var body: some View {
        NavigationView{
            List {
                ForEach(bands) {
                    band in
                    NavigationLink {
                        Detail(band: band)
                    } label: {
                        BandRow(band: band)
                    }
                }
            }
            .navigationTitle("Band")
        }
    }
}

struct BandList_Previews: PreviewProvider {
    static var previews: some View {
        BandList()
    }
}
