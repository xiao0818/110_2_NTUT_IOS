//
//  LogInView.swift
//  lab10
//
//  Created by Eddie on 2022/6/1.
//

import SwiftUI
import FirebaseAuth

struct LogInView: View {
    @State private var username = (Auth.auth().currentUser != nil) ? ((Auth.auth().currentUser?.displayName != nil) ? (Auth.auth().currentUser?.displayName)! : "") : ""
    @State private var email = (Auth.auth().currentUser != nil) ? (Auth.auth().currentUser?.email)! : ""
    @EnvironmentObject var state: LogInState
    
    var body: some View {
        VStack {
            Text("username: " + username)
                .padding()
            Text("email: " + email)
                .padding()
            NavigationLink {
                LazyView(DelayView())
            } label: {
                Text("LOGOUT")
                    .frame(width: 200)
                    .padding()
                    .foregroundColor(.white)
                    .background(.blue)
                    .border(.gray , width: 1)
            }
            .simultaneousGesture(TapGesture().onEnded({
                do {
                    try Auth.auth().signOut()
                    sleep(1)
                    state.isGoLogInView = (Auth.auth().currentUser != nil)
                    state.isGoSignInView = ((Auth.auth().currentUser != nil) == false)
                } catch {
                    print(error)
                }
            }))
            HStack {
                Text("Want to change username? ")
                    .foregroundColor(.gray)
                NavigationLink {
                    LazyView(SettingView())
                } label: {
                    Text("Setting")
                        .foregroundColor(.blue)
                }
            }
        }
        .padding()
        .border(.blue , width: 3)
        .navigationBarTitle("")
        .navigationBarHidden(true)
    }
}

struct LogInView_Previews: PreviewProvider {
    static var previews: some View {
        LogInView()
    }
}
