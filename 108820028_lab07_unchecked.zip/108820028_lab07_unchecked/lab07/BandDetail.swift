//
//  BandDetail.swift
//  lab07
//
//  Created by Eddie on 2022/5/11.
//

import SwiftUI

struct BandDetail: View {
    let band: Band
    
    var body: some View {
        VStack (alignment: .center){
            Image(band.name)
                .resizable()
                .scaledToFill()
            Text(band.description)
        }
    }
}

struct BandDetail_Previews: PreviewProvider {
    static var previews: some View {
        BandDetail(band: .demoBand)
    }
}
