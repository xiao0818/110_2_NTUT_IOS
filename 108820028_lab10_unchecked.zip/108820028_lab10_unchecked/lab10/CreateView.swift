//
//  CreateView.swift
//  lab10
//
//  Created by Eddie on 2022/6/1.
//

import SwiftUI
import FirebaseAuth

struct CreateView: View {
    @State private var email = ""
    @State private var password = ""
    @EnvironmentObject var state: LogInState
    
    var body: some View {
        VStack {
            TextField("email", text: $email)
                .frame(width: 200)
                .padding()
                .background(.bar)
                .border(.gray , width: 1)
            TextField("password", text: $password)
                .frame(width: 200)
                .padding()
                .background(.bar)
                .border(.gray , width: 1)
            NavigationLink {
                LazyView(DelayView())
            } label: {
                Text("CREATE")
                    .frame(width: 200)
                    .padding()
                    .foregroundColor(.white)
                    .background(.blue)
                    .border(.gray , width: 1)
            }
            .simultaneousGesture(TapGesture().onEnded({
                Auth.auth().createUser(withEmail: email, password: password)
                sleep(1)
                state.isGoLogInView = (Auth.auth().currentUser != nil)
                state.isGoSignInView = ((Auth.auth().currentUser != nil) == false)
            }))
            HStack {
                Text("Already registered? ")
                    .foregroundColor(.gray)
                NavigationLink {
                    LazyView(SignInView())
                } label: {
                    Text("Sign In")
                        .foregroundColor(.blue)
                }
            }
        }
        .padding()
        .border(.blue , width: 3)
        .navigationBarTitle("")
        .navigationBarHidden(true)
    }
}

struct CreateView_Previews: PreviewProvider {
    static var previews: some View {
        CreateView()
    }
}
