//
//  Band.swift
//  lab07
//
//  Created by Eddie on 2022/5/11.
//

import Foundation

struct Band: Identifiable {
    var id: String { name }
    let name: String
    let description: String
    let youtubeUrl: String
    let instagramUrl: String
    let facebookUrl: String
    let streetVoiceUrl: String
    let records: [Record]
}

extension Band {
    static let demoBand = Band(name: "Vast & Hazy", description: "@vastandhazyofficial\nVH (Vast & Hazy)\n音樂家／樂團\n雙人創作組合 #VH #VastandHazy\n咖咖 @ka_ka_yen 易祺 @gorocktogether\n💿 文明 The Great Beyond 💿：\nbit.ly/3LhdAuj", youtubeUrl: "https://www.youtube.com/user/vasthazy/videos", instagramUrl: "https://www.instagram.com/vastandhazyofficial/?hl=zh-tw", facebookUrl: "https://www.facebook.com/VastandHazy", streetVoiceUrl: "https://streetvoice.com/VastHazy/", records: [.demoRecord])
}
