//
//  lab07App.swift
//  lab07
//
//  Created by Eddie on 2022/5/11.
//

import SwiftUI

@main
struct lab07App: App {
    var body: some Scene {
        WindowGroup {
            BandList()
        }
    }
}
