//
//  ContentView.swift
//  practice
//
//  Created by Eddie on 2022/5/2.
//

import SwiftUI

struct ContentView: View {
    let records = ["yet,", "Vast&Hazy", "次等秘密", "求救訊號", "文明"]
    @State private var imageScale = 1.0
    @State private var name = ""
    @State private var date = Date()
    @State private var isConcert = false
    @State private var times = 0
    @State private var recordSelectedIndex = 0
    @State private var showAlert = false
    @State var alertMessage = ""
    var body: some View {
        VStack (alignment: .center) {
            Text("Vast & Hazy")
                .font(.largeTitle)
            
            Image("Vast & Hazy")
                .resizable()
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.black, lineWidth: 3))
                .frame(width: 240, height: 240)
                .scaleEffect(imageScale)
            
            Slider(value: $imageScale, in: 0...1) {
            } minimumValueLabel: {
                Text("0%")
            } maximumValueLabel: {
                Text("100%")
            }
            
            TextField("Your Name", text: $name, prompt: Text("Your Name"))
                .padding()
                .cornerRadius(40)
                .overlay(RoundedRectangle(cornerRadius: 40).stroke(Color.blue, lineWidth: 3))
            
            VStack (alignment: .leading) {
                DatePicker("Time for first hearing them", selection: $date, displayedComponents: .date)
                
                Toggle(isOn: $isConcert) {
                    Text("Have you ever attended their concert")
                }
                
                let string = "Attended their concerts " + String(times) + " times"
                Stepper(string, onIncrement: {
                    times += 1
                }, onDecrement: {
                    times -= 1
                })
                
                Text("Favorite Record")
                Picker(selection: $recordSelectedIndex){
                    ForEach (records.indices) { record in Text(records[record])}
                } label: {
                    Text("Favorite record")
                }
                .pickerStyle(.segmented)
            }
            
            Button {
                showAlert = true
                let string1 = "Your name is " + name + ".\n"
                let string2 = "Time for first hearing them is " + date.formatted(date: .long, time: .omitted) + ".\n"
                let string3 = isConcert ? "You have ever attended their concert.\n" : "You have never attended their concert.\n"
                let string4 = "You have ever attended their concerts " + String(times) + " times.\n"
                let string5 = "Your favorite record is " + records[recordSelectedIndex] + "."
                alertMessage = string1 + string2 + string3 + string4 + string5
            } label: {
                Text("Submit")
                    .padding()
                    .background(.blue)
                    .foregroundColor(.white)
                    .cornerRadius(40)
            }
            .alert("Please check your message", isPresented: $showAlert, actions: {
                Button("OK") {
                }
            }, message: {
                Text(alertMessage)
            })
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
