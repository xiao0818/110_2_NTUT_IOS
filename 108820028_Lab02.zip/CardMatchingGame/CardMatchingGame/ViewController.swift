//
//  ViewController.swift
//  CardMatchingGame
//
//  Created by Eddie on 2022/3/9.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var flipLabel: UILabel!
    
    var flipCount: Int = 0{
        didSet{
            flipLabel.text = "Flip: \(flipCount)"
        }
    }
    
    @IBOutlet var cardButtons: [UIButton]!
    
    var emojis = ["🌚", "🌛", "🌛", "🌝", "🌝", "🌜", "🌜", "🌚"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emojis.shuffle()
        // Do any additional setup after loading the view.
    }

    @IBAction func flipCard(_ sender: UIButton) {
        let cardNumber = cardButtons.firstIndex(of: sender)
        
        if sender.currentTitle == emojis[cardNumber!]{
            sender.setTitle("", for: UIControl.State.normal)
            sender.backgroundColor = #colorLiteral(red: 1, green: 0.8, blue: 0, alpha: 1)
            }else{
            sender.setTitle(emojis[cardNumber!], for: UIControl.State.normal)
            sender.backgroundColor = #colorLiteral(red: 0.9254091382, green: 0.9255421162, blue: 0.9253799319, alpha: 1)
            }
        flipCount += 1
    }
    
}

