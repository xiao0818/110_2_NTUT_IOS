//
//  ViewController.swift
//  BMI
//
//  Created by Eddie on 2022/3/2.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet var height: UITextField!
    @IBOutlet var weight: UITextField!
    @IBOutlet var gender: UISegmentedControl!
    @IBOutlet var bmiResult: UILabel!
    @IBOutlet var weightStatus: UILabel!
    
    @IBAction func Caculate(_ sender: Any) {
        let h:Float! = Float(height.text!)!
        let w:Float! = Float(weight.text!)!
        var bmi:Float
        bmi = Float(w / h / h * 10000)
        bmiResult.text = String(bmi)
        if (bmi < 18.5){
            weightStatus.text = "Underweight"
        } else if (bmi < 24.9){
            weightStatus.text = "Healthy weight"
        } else if (gender.selectedSegmentIndex == 1){
            weightStatus.text = "it's a secret"
        } else if (bmi < 29.9){
            weightStatus.text = "Overweight"
        } else{
            weightStatus.text = "Obesity"
        }
    }
}

