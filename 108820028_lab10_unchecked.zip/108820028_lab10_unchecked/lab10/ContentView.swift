//
//  ContentView.swift
//  lab10
//
//  Created by Eddie on 2022/6/2.
//

import SwiftUI
import FirebaseAuth

struct ContentView: View {
    @EnvironmentObject var state: LogInState
    
    var body: some View {
        NavigationView{
            VStack {
                NavigationLink("", destination: LazyView(LogInView()), isActive: $state.isGoLogInView)
                NavigationLink("", destination: LazyView(SignInView()), isActive: $state.isGoSignInView)
            }
        }
        .navigationBarTitle("")
        .navigationBarHidden(true)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
