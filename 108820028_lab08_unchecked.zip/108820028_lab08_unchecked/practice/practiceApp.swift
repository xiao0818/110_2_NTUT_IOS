//
//  practiceApp.swift
//  practice
//
//  Created by Eddie on 2022/5/2.
//

import SwiftUI

@main
struct practiceApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
