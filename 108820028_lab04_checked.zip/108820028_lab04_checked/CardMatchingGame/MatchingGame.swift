import Foundation

class MatchingGame{
    var cards: Array<Card> = Array()
    var flipUp: Bool = false
    var flipCount: Int = 0
    
    var indexOfOneAndOnlyFaceUpCard: Int?{
        get{
            var foundIndex: Int?
            for index in cards.indices{
                if cards[index].isFaceUp, !cards[index].isMatched{
                    if foundIndex == nil{
                        foundIndex = index
                    }else{
                        return nil
                    }
                }
            }
            return foundIndex
        }
        set(newValue){
            for index in cards.indices{
                cards[index].isFaceUp = (index == newValue)
                if cards[index].isMatched{
                    cards[index].isFaceUp = true
                }
            }
        }
    }
    
    func chooseCard(at index: Int){
        if cards[index].isMatched == false{
            flipCount += 1
        }
        
        if !cards[index].isMatched{
            if let matchIndex = indexOfOneAndOnlyFaceUpCard, matchIndex != index{
                if cards[matchIndex].identifier == cards[index].identifier{
                    cards[matchIndex].isMatched = true
                    cards[index].isMatched = true
                }
                cards[index].isFaceUp = true
//                indexOfOneAndOnlyFaceUpCard = nil
            }else if let matchIndex = indexOfOneAndOnlyFaceUpCard, matchIndex == index{
                cards[index].isFaceUp = false
//                indexOfOneAndOnlyFaceUpCard = nil
            }else{
//                for flipDownIndex in cards.indices{
//                    if !cards[flipDownIndex].isMatched{
//                        cards[flipDownIndex].isFaceUp = false
//                    }
//                }
//              cards[index].isFaceUp = true
                indexOfOneAndOnlyFaceUpCard = index
            }
        }
    }
    
    init(numberOfPairsOfCards: Int){
        for _ in 1...numberOfPairsOfCards{
            let card = Card()
            cards += [card, card]
            cards.shuffle()
        }
    }
    
    func FlipAll(){
        flipCount = 0
        flipUp = true
        for index in cards.indices{
            flipUp = flipUp && cards[index].isFaceUp
        }
        
        if flipUp == true{
            for index in cards.indices{
                cards[index].isMatched = false
                cards[index].isFaceUp = false
            }
            indexOfOneAndOnlyFaceUpCard = nil
        }else{
            for index in cards.indices{
                cards[index].isMatched = true
                cards[index].isFaceUp = true
            }
            indexOfOneAndOnlyFaceUpCard = nil
        }
    }
    
    func Reset(){
        flipCount = 0
        for index in cards.indices{
            cards[index].isMatched = false
            cards[index].isFaceUp = false
        }
        cards.shuffle()
        indexOfOneAndOnlyFaceUpCard = nil
    }
    
    func AllFaceUp() -> Bool{
        flipUp = true
        for index in cards.indices{
            flipUp = flipUp && cards[index].isFaceUp
        }
        
        return flipUp
    }
}
