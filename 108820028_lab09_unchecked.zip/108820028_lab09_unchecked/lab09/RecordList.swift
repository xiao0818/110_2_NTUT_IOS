//
//  RecordList.swift
//  lab09
//
//  Created by Eddie on 2022/5/25.
//

import SwiftUI

struct RecordList: View {
    @EnvironmentObject var records: Records
    
    var body: some View {
        List {
            ForEach(records.records) {
                record in
                NavigationLink {
                    RecordDetail(record: record)
                } label: {
                    RecordRow(record: record)
                }
            }
        }
    }
}

struct RecordList_Previews: PreviewProvider {
    static var previews: some View {
        RecordList()
            .environmentObject(Records())
    }
}
