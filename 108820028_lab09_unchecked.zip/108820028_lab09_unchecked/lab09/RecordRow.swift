//
//  RecordRow.swift
//  lab09
//
//  Created by Eddie on 2022/5/25.
//

import SwiftUI

struct RecordRow: View {
    let record: Record
    
    var body: some View {
        HStack {
            Image(record.name)
                .resizable()
                .scaledToFill()
                .frame(width: 80, height: 80)
                .clipped()
            VStack (alignment: .leading) {
                Text(record.name)
                Text(record.band)
            }
            Spacer()
        }
    }
}

struct RecordRow_Previews: PreviewProvider {
    static var previews: some View {
        RecordRow(record: .demoRecord)
    }
}
