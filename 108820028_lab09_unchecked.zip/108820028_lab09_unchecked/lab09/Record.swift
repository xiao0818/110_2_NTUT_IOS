//
//  Record.swift
//  lab09
//
//  Created by Eddie on 2022/5/25.
//

import Foundation

struct Record: Identifiable {
    var id: String { name }
    let name: String
    let band: String
    let description: String
}

extension Record {
    static let demoRecord = Record(name: "yet,", band: "Vast & Hazy", description: "yet,\n1 首歌\n1. yet,")
}
