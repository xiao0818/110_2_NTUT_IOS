//
//  lab06App.swift
//  lab06
//
//  Created by Eddie on 2022/5/4.
//

import SwiftUI

@main
struct lab06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
