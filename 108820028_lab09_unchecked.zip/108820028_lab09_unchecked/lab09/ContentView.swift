//
//  ContentView.swift
//  lab09
//
//  Created by Eddie on 2022/5/25.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var records: Records
    
    var body: some View {
        NavigationView{
            VStack {
                RecordList()
                NavigationLink {
                    AddRecordView()
                } label: {
                    Text(" + Add Record ")
                        .padding()
                        .background(.blue)
                        .foregroundColor(.white)
                        .cornerRadius(40)
                }
            }
            .navigationTitle("Records List")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(Records())
    }
}
