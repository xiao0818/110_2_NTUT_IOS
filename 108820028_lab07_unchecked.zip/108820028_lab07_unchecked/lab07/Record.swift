//
//  Record.swift
//  lab07
//
//  Created by Eddie on 2022/5/11.
//

import Foundation

struct Record: Identifiable {
    var id: String { name }
    let name: String
    let description: String
}

extension Record {
    static let demoRecord = Record(name: "yet,", description: "yet,\n1 首歌\n1. yet,")
}
