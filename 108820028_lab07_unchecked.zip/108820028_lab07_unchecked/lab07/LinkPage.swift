//
//  LinkPage.swift
//  lab07
//
//  Created by Eddie on 2022/5/11.
//

import SwiftUI

struct LinkPage: View {
    let band: Band
    
    var body: some View {
        VStack {
            ScrollView(.horizontal) {
                let rows = [GridItem()]
                LazyHGrid(rows: rows) {
                    Link(destination: URL(string: band.youtubeUrl)!, label: {
                        Image("youtube")
                            .resizable()
                            .frame(width: 200, height: 200)
                    })
                    Link(destination: URL(string: band.instagramUrl)!, label: {
                        Image("instagram")
                            .resizable()
                            .frame(width: 200, height: 200)
                    })
                    Link(destination: URL(string: band.facebookUrl)!, label: {
                        Image("facebook")
                            .resizable()
                            .frame(width: 200, height: 200)
                    })
                    Link(destination: URL(string: band.streetVoiceUrl)!, label: {
                        Image("streetVoice")
                            .resizable()
                            .frame(width: 200, height: 200)
                    })
                }
            }
        }
    }
}

struct LinkPage_Previews: PreviewProvider {
    static var previews: some View {
        LinkPage(band: .demoBand)
    }
}
