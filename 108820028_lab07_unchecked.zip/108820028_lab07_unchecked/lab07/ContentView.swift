//
//  ContentView.swift
//  lab07
//
//  Created by Eddie on 2022/5/11.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        BandList()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
