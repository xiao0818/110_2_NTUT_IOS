//
//  lab09App.swift
//  lab09
//
//  Created by Eddie on 2022/5/25.
//

import SwiftUI

@main
struct lab09App: App {
    @StateObject private var records = Records()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(records)
        }
    }
}
