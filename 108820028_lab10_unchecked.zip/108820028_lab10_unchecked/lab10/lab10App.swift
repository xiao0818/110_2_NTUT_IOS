//
//  lab10App.swift
//  lab10
//
//  Created by Eddie on 2022/6/1.
//

import SwiftUI
import Firebase

@main
struct lab10App: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject private var state = LogInState()
    var body: some Scene {
        WindowGroup {
            LazyView(DelayView())
                .environmentObject(state)
        }
    }
}
