//
//  RecordDetail.swift
//  lab09
//
//  Created by Eddie on 2022/5/25.
//

import SwiftUI

struct RecordDetail: View {
    let record: Record
    
    var body: some View {
        VStack (alignment: .center){
            Image(record.name)
                .resizable()
                .scaledToFill()
            HStack (alignment: .top) {
                VStack {
                    Image(record.band)
                        .resizable()
                        .frame(width: 100, height: 100, alignment: .leading)
                    Text(record.band)
                }
                Text(record.description)
            }
        }
        .navigationTitle(record.name)
    }
}

struct RecordDetail_Previews: PreviewProvider {
    static var previews: some View {
        RecordDetail(record: .demoRecord)
    }
}
